import * as pdfjs from 'pdfjs-dist';
import worker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import {createWorker} from 'tesseract.js';
pdfjs.GlobalWorkerOptions.workerSrc=worker;
export const samples = {
 prescription: {name:'Sample prescription',text:'FICTIONAL DEMONSTRATION — NOT FOR CLINICAL USE\nMediExplain Demo Clinic\nPatient: Alex Sample (fictional adult)\nDate: 12 November 2026\nPrescription: Amoxicillin 500 mg capsule\nDirections: Take one capsule by mouth three times daily for 5 days.\nPrescriber note: Confirm allergy history with pharmacist before use.\nSignature: [unreadable]'},
 lab: {name:'Sample blood report',text:'FICTIONAL DEMONSTRATION — NOT FOR CLINICAL USE\nMediExplain Sample Laboratory\nPatient: Alex Sample (fictional adult)\nComplete Blood Count\nHemoglobin: 11.2 g/dL (reference: 12.0–16.0 g/dL)\nWhite blood cell count: 7.1 x10^9/L (reference: 4.0–11.0 x10^9/L)\nPlatelets: 250 x10^9/L (reference: 150–400 x10^9/L)\nLaboratory note: Interpret results with clinical history.\nCollection date: 12 November 2026'}
};
export async function extract(file:File, progress:(s:string)=>void):Promise<string>{
 const head=new Uint8Array(await file.slice(0,8).arrayBuffer());
 const isPDF=head[0]===37&&head[1]===80&&head[2]===68&&head[3]===70;
 const isImage=(head[0]===137&&head[1]===80&&head[2]===78&&head[3]===71)||(head[0]===255&&head[1]===216);
 if(!isPDF&&!isImage) throw Error('This file is not a valid PDF, PNG, or JPEG.');
 let ocr:Awaited<ReturnType<typeof createWorker>>|undefined;
 const recognize=async(input:File|HTMLCanvasElement)=>{
  if(!ocr)ocr=await createWorker('eng+urd',1,{logger:m=>{if(m.status==='recognizing text')progress(`Reading text… ${Math.round(m.progress*100)}%`);}});
  return (await ocr.recognize(input)).data.text;
 };
 try{
  if(!isPDF)return await recognize(file);
  const pdf=await pdfjs.getDocument({data:await file.arrayBuffer()}).promise;
  try {
   if(pdf.numPages>15)throw Error('Please upload a PDF with 15 pages or fewer.');
   const parts:string[]=[];
   for(let n=1;n<=pdf.numPages;n++){
    progress(`Reading page ${n} of ${pdf.numPages}…`);
    const page=await pdf.getPage(n);const content=await page.getTextContent();
    let text=content.items.map(i=>'str' in i?i.str:'').join(' ');
    if(text.trim().length<30){
     const viewport=page.getViewport({scale:1.6});if(viewport.width*viewport.height>16000000)throw Error('This scanned page is too large. Upload a smaller image.');
     const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;
     await page.render({canvasContext:canvas.getContext('2d')!,viewport}).promise;
     text=await recognize(canvas);canvas.width=canvas.height=0;
    }
    parts.push(`[Page ${n}]\n${text}`);
   }
   return parts.join('\n\n');
  }finally{await pdf.destroy();}
 }finally{await ocr?.terminate();}
}

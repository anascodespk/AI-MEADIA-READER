# MediExplain

**Understand Your Health, Simply.** An educational healthcare accessibility prototype for SDG 3. React + TypeScript + Vite + Tailwind CSS frontend, FastAPI + Pydantic backend, and real Gemini REST integration.

## Run locally

Requires Node 20.19+ and Python 3.11+.

```bash
npm ci
python -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
cp backend/.env.example .env
```

Edit `.env`: set a server-only `GEMINI_API_KEY`, choose a currently supported `GEMINI_MODEL` (default `gemini-2.5-flash`), and set comma-separated `ALLOWED_ORIGINS` to your frontend origins. Never prefix the key with `VITE_` or put it in browser settings.

In separate terminals, from the project root:

```bash
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --no-access-log
```

```bash
npm run dev
```

Open the Vite URL (normally http://localhost:5173). Its `/api` proxy forwards to FastAPI. Leave the app's backend URL setting blank for local development. API documentation: http://localhost:8000/docs. Health endpoint: `/api/health`, including `aiConfigured`.

## Demonstrate

1. Open Overview and load either **fictional** prescription or blood report.
2. Review and edit the text. Select English, Urdu, or Roman Urdu.
3. Read the sharing consent and check the box, then **Explain with AI**.
4. Review summary, terminology with exact source quotes, important details, uncertainties, and questions for a doctor.
5. Ask a follow-up, listen, copy, print, or download. Language changes require a new AI request using the regenerate control.
6. Load the other sample to demonstrate genuinely different model output.

No prewritten AI output is used. Without a backend/key the app shows an actionable error. Live Gemini quality, multilingual output and chat need end-to-end verification with your own valid server key; no key was supplied during development.

## Document processing

- PNG/JPEG/PDF validation: extension, file signature, 10 MB size, maximum 15 PDF pages, 40,000 extracted characters.
- PDF.js extracts selectable text; pages with fewer than 30 text characters use OCR.
- Tesseract.js reads English and Urdu images and scanned pages. OCR runtime/language assets are fetched from its default public CDNs; internet is required on first use. Long OCR operations show progress. Handwriting recognition is unreliable: manually verify extracted text, especially dosages and units.
- Files stay in browser memory. Only reviewed text is sent after explicit consent to the configured backend, then Google Gemini. Do not use real patient information for a hackathon demo.
- Session records stay in React memory (last 10 analyses), cleared on refresh. The backend stores no records. Only a backend URL preference is stored in localStorage.

## Build and checks

```bash
npm run build
python -m pytest backend/tests -q
```

`dist/` is the production frontend. Configure your static host to rewrite application routes (`/analyzer`, `/results`, etc.) to `index.html`. Vite handles this in development. Sites static hosting supports the SPA fallback.

## Deploy

The included Sites manifest deploys the frontend only; Sites Workers do not run Python/FastAPI. Deploy `backend/` on a Python host or container, then enter its HTTPS origin in the frontend's Settings. Configure `ALLOWED_ORIGINS` with the exact published frontend origin. Set the Gemini key/model as server environment secrets. Do not expose FastAPI development reload in production.

A backend Dockerfile is included. Example:

```bash
docker build -t mediexplain-api -f backend/Dockerfile .
docker run --rm -p 8000:8000 --env-file .env mediexplain-api
```

Before opening a public Gemini-backed service, add appropriate authentication, per-user rate limiting, request-size controls at the reverse proxy, and usage quotas. This hackathon prototype has no user authentication on the FastAPI API. CORS alone does not prevent unauthorized API callers. Keep the hosted frontend private while evaluating.

## Safety boundaries

AI is educational, not a clinician. System instructions forbid diagnosis, prescribing, dose calculation, treatment changes, and following instructions embedded in documents. Model output is validated with Pydantic; glossary and chat source quotes are verified as exact substrings. This verifies quotations, **not** medical correctness or complete factual grounding. Prompt safeguards do not guarantee safety and require clinical and adversarial evaluation before real-world deployment. Unclear content should be verified with a doctor/pharmacist. Potential urgent symptoms should prompt appropriate urgent medical assistance.

Gemini failures, quota errors, missing key, malformed responses and timeouts produce errors with retry through the original control. No document text or API responses are logged. Verify your infrastructure and provider retention/logging policies independently.

## Accessibility and export

Keyboard focus indicators, accessible labels, responsive layout, reduced-motion support, and Urdu RTL result content are included. Speech synthesis uses installed browser voices; unavailable Urdu voices produce an explicit fallback. PDF export uses jsPDF for English/Roman Urdu; Urdu uses browser Print → Save as PDF to preserve shaping and glyphs. Browser voice, clipboard, and print support vary.

## Structure

- `src/main.tsx` — routed workspace, upload/review/results/chat/history, consent, settings.
- `src/documents.ts` — synthetic sources and actual PDF/OCR pipeline.
- `src/types.ts` — shared frontend data structures.
- `src/style.css` — responsive UI and print styles.
- `backend/main.py` — stateless validated Gemini API.
- `backend/tests/` — consent/size/language and missing-key checks.
- `backend/.env.example` — server configuration template.

Future clinic/pharmacy integrations and paid plans are concepts, not implemented capabilities. No database, billing, clinical validation or production compliance certification is included.

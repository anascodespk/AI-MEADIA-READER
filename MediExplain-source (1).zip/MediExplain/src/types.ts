export type Language='English'|'Urdu'|'Roman Urdu';
export type Analysis={documentType:string;summary:string;medicalTerms:{term:string;explanation:string;sourceText:string}[];importantDetails:string[];unclearInformation:string[];questionsForDoctor:string[];disclaimer:string};
export type RecordItem={id:string;name:string;text:string;language:Language;result:Analysis;time:string};

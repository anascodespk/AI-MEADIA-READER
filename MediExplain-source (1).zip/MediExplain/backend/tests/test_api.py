import asyncio
import os
import pytest
from fastapi import HTTPException
from pydantic import ValidationError
from backend.main import Request, Analysis, generate

def test_consent_and_size_validation():
    with pytest.raises(ValidationError): Request(text='Valid fictional document text', consent=False)
    with pytest.raises(ValidationError): Request(text='x'*40001, consent=True)
    with pytest.raises(ValidationError): Request(text='Valid fictional document text', consent=True, language='French')

def test_missing_key_never_returns_fake_result(monkeypatch):
    monkeypatch.delenv('GEMINI_API_KEY', raising=False)
    with pytest.raises(HTTPException) as error:
        asyncio.run(generate(Request(text='Fictional report. Hemoglobin: 13 g/dL.', consent=True), Analysis))
    assert error.value.status_code == 503

from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_api_rejects_no_consent():
    response = client.post('/api/analyze', json={'text':'Fictional lab report text.', 'consent':False})
    assert response.status_code == 422

def test_health_has_no_secret(monkeypatch):
    monkeypatch.setenv('GEMINI_API_KEY', 'secret-test-value')
    response = client.get('/api/health')
    assert response.json() == {'status':'ok', 'aiConfigured':True}
    assert 'secret-test-value' not in response.text

def mock_gemini(monkeypatch, output):
    import httpx
    class FakeClient:
        def __init__(self, **kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        async def post(self, url, **kwargs):
            assert kwargs['headers']['x-goog-api-key'] == 'test-key'
            assert 'untrusted' in kwargs['json']['systemInstruction']['parts'][0]['text']
            import json
            return httpx.Response(200, json={'candidates':[{'content':{'parts':[{'text':json.dumps(output)}]}}]})
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    monkeypatch.setattr('backend.main.httpx.AsyncClient', FakeClient)

def test_chat_rejects_fabricated_quote(monkeypatch):
    mock_gemini(monkeypatch, {'answer':'Example model output for contract testing.', 'sourceReferences':['invented source quote']})
    response = client.post('/api/chat', json={'text':'FICTIONAL: Hemoglobin 11.2 g/dL.', 'language':'English', 'consent':True, 'question':'Explain hemoglobin.'})
    assert response.status_code == 502

def test_analysis_validates_and_returns_document_quote(monkeypatch):
    mock_gemini(monkeypatch, {'documentType':'lab report','summary':'Synthetic contract test response.', 'medicalTerms':[{'term':'Hemoglobin','explanation':'Test explanation.', 'sourceText':'Hemoglobin 11.2 g/dL'}], 'importantDetails':[], 'unclearInformation':[], 'questionsForDoctor':[], 'disclaimer':'model disclaimer'})
    response = client.post('/api/analyze', json={'text':'FICTIONAL: Hemoglobin 11.2 g/dL.', 'language':'Urdu', 'consent':True})
    assert response.status_code == 200
    assert response.json()['medicalTerms'][0]['sourceText'] == 'Hemoglobin 11.2 g/dL'
    assert response.json()['disclaimer'].startswith('MediExplain provides educational')
